import java.net.*;
import java.io.*;
import java.util.concurrent.*;

public class Server
{
	public static void main( String[] args )
	{
	}
}

