import java.io.*;
import java.net.*;
import java.util.*;

public class Client
{
	public static void main( String[] args )
	{
	}
}
